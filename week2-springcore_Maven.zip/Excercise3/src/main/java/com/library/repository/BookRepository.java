package com.library.repository;

public class BookRepository {
    public void saveBook() {
        System.out.println("Book is saved to the repository");
    }

    public void deleteBook() {
        System.out.println("Book is deleted from the repository");
    }
}
