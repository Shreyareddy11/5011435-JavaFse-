package com.library.service;

public class BookService {
    public void addBook() {
        System.out.println("Book is added");
    }

    public void removeBook() {
        System.out.println("Book is removed");
    }
}
