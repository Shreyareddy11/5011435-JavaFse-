package com.ex9.Excercise9;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Excercise9ApplicationTests {

	@Test
	void contextLoads() {
	}

}
