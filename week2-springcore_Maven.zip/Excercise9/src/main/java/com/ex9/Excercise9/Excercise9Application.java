package com.ex9.Excercise9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Excercise9Application {

	public static void main(String[] args) {
		SpringApplication.run(Excercise9Application.class, args);
	}

}
