package com.library.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

public class LoggingAspect {
    public void logBefore() {
        System.out.println("LoggingAspect: Before method execution");
    }
    public void logAfter() {
        System.out.println("LoggingAspect: After method execution");
    }
}
