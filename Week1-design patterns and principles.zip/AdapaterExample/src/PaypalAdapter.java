public class PaypalAdapter implements PaymentProcessor {
    private Paypal payPal;

    public PaypalAdapter(Paypal payPal) {
        this.payPal = payPal;
    }

    @Override
    public void processPayment(double amount) {
        payPal.makePayment(amount);
    }
}
