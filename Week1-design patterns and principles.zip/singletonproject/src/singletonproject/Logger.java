package singletonproject;

public class Logger {
    // Step 2.1: Private static instance of Logger class
    private static Logger instance;

    // Step 2.2: Private constructor to prevent instantiation
    private Logger() {
        // Optional: Initialize resources
    }

    // Step 2.3: Public static method to get the instance of Logger class
    public static Logger getInstance() {
        if (instance == null) {
            instance = new Logger();
        }
        return instance;
    }

    // Optional: Method to log messages
    public void log(String message) {
        System.out.println(message);
    }
}
