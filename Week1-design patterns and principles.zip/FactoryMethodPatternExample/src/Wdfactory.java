public class Wdfactory extends Documentfactory {
    @Override
    public Document createDocument() {
        return new Word();
    }
}
