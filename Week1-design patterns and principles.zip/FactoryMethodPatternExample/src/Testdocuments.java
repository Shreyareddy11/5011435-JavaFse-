
public class Testdocuments {
    public static void main(String[] args) {
        Documentfactory wordFactory = new Wdfactory();
        Documentfactory pdfFactory = new Pdfactory();
        Documentfactory excelFactory = new Edfactory();

        Document wordDoc = wordFactory.createDocument();
        Document pdfDoc = pdfFactory.createDocument();
        Document excelDoc = excelFactory.createDocument();

        wordDoc.open();
        wordDoc.close();

        pdfDoc.open();
        pdfDoc.close();

        excelDoc.open();
        excelDoc.close();
    }
}


