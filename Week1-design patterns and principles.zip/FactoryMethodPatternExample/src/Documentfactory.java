public abstract class Documentfactory {
    public abstract Document createDocument();
}
