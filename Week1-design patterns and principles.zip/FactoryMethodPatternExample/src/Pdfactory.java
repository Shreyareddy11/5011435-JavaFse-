public class Pdfactory extends Documentfactory {
    @Override
    public Document createDocument() {
        return new Pdf();
    }
}
