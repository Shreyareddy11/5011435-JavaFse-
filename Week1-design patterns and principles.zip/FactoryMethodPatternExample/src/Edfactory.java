public class Edfactory extends Documentfactory {
    @Override
    public Document createDocument() {
        return new Excel();
    }
}

