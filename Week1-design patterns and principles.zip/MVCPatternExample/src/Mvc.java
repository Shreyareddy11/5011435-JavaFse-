
public class Mvc {
    public static void main(String[] args) {
        
        Student student = new Student("1", "shreya", "A+");
        Studentview view = new Studentview();
        StudentController controller = new StudentController(student, view);
        controller.updateView();
        controller.setStudentName("Shreya");
        controller.setStudentGrade("A");
        controller.updateView();
    }
}
