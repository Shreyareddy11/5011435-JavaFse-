package BookStoreAPI.example.bsae14;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bsae14ApplicationTests {

	@Test
	void contextLoads() {
	}

}
