package BookStoreAPI.example.bsae14;

public class BookService {

	public Object getAllBooks() {
		// TODO Auto-generated method stub
		return null;
	}

}
