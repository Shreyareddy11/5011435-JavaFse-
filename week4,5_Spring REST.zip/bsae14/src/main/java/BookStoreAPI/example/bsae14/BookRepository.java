package BookStoreAPI.example.bsae14;

public class BookRepository {

	public void save(Book book) {
		// TODO Auto-generated method stub
		
	}

}
