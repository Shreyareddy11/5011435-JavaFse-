package BookStoreAPI.example.bsae14;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
public class BookControllerIntegrationTest {

    private static final String MockMvcRequestBuilders = null;

	@Autowired
    private MockMvc mockMvc;

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private ObjectMapper objectMapper;

	private Object MockMvcResultMatchers;

    public void testGetAllBooks() throws Exception {
        // Save some books to the in-memory database
        bookRepository.save(new Book());
        bookRepository.save(new Book());
    }

  
    public void testAddBook() throws Exception {
        // Create a new book and convert it to JSON
        Book book = new Book();
        String bookJson = objectMapper.writeValueAsString(book);

    }


	private Object status() {
		// TODO Auto-generated method stub
		return null;
	}
}
