package BookstoreAPI.example.bsaex1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bsaex1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
