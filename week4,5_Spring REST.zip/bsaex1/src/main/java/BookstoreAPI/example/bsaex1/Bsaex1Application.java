package BookstoreAPI.example.bsaex1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bsaex1Application {

	public static void main(String[] args) {
		SpringApplication.run(Bsaex1Application.class, args);
	}

}
