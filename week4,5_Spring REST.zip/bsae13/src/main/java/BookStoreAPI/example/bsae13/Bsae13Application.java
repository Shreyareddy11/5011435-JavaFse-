package BookStoreAPI.example.bsae13;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bsae13Application {

	public static void main(String[] args) {
		SpringApplication.run(Bsae13Application.class, args);
	}

}
