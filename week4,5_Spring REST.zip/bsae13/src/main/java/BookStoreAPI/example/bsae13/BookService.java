package BookStoreAPI.example.bsae13;

import java.awt.print.Book;
import java.util.List;

import org.springframework.http.StreamingHttpOutputMessage.Body;

public class BookService {

	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		return null;
	}

	public Book addBook(Book book) {
		// TODO Auto-generated method stub
		return null;
	}

}
