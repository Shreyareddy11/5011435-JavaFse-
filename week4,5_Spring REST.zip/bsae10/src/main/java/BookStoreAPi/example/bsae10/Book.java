package BookStoreAPi.example.bsae10;

public class Book {

	public Object getTitle() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getAuthor() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getPrice() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getIsbn() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setTitle(Object title) {
		// TODO Auto-generated method stub
		
	}

	public void setAuthor(Object author) {
		// TODO Auto-generated method stub
		
	}

	public void setPrice(Object price) {
		// TODO Auto-generated method stub
		
	}

	public void setIsbn(Object isbn) {
		// TODO Auto-generated method stub
		
	}

}
