package BookStoreAPi.example.bsae10;

import java.util.List;

public class BookRepository {

	public List<Book> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object findById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public Book save(Book book) {
		// TODO Auto-generated method stub
		return null;
	}

	public void delete(Book book) {
		// TODO Auto-generated method stub
		
	}

}
