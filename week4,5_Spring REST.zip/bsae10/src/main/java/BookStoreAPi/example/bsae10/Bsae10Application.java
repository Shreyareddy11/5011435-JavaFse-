package BookStoreAPi.example.bsae10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bsae10Application {

	public static void main(String[] args) {
		SpringApplication.run(Bsae10Application.class, args);
	}

}
