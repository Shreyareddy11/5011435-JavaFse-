package BookStoreAPI.example.bsae15;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bsae15ApplicationTests {

	@Test
	void contextLoads() {
	}

}
