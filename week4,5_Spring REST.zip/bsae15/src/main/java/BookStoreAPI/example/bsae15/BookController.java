package BookStoreAPI.example.bsae15;
import java.awt.print.Book;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/books")
public class BookController {

 
    public List<Book> getAllBooks() {
		return null;
        // Implementation here
    }

    public void addBook(@RequestBody Book book) {
        // Implementation here
    }
}
