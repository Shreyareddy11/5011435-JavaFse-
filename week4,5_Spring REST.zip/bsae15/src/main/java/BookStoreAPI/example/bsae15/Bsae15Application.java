package BookStoreAPI.example.bsae15;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bsae15Application {

	public static void main(String[] args) {
		SpringApplication.run(Bsae15Application.class, args);
	}

}
