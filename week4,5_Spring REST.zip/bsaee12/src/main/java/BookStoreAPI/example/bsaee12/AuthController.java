package BookStoreAPI.example.bsaee12;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/login")
    public String login(@RequestBody UserCredentials credentials) {
        // Authenticate user (you would replace this with actual authentication logic)
        if ("user".equals(credentials.getUsername()) && "password".equals(credentials.getPassword())) {
            return jwtUtil.generateToken(credentials.getUsername());
        } else {
            throw new RuntimeException("Invalid credentials");
        }
    }
}
