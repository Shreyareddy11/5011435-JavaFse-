package BookStoreAPI.example.bsaee12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bsaee12Application {

	public static void main(String[] args) {
		SpringApplication.run(Bsaee12Application.class, args);
	}

}
