package BookStoreAPI.example.bsaee12;
public class UserCredentials {
    private String username;
    private String password;
	public Object getUsername() {
		// TODO Auto-generated method stub
		return null;
	}
	public Object getPassword() {
		// TODO Auto-generated method stub
		return null;
	}

    // Getters and setters
}
