package org.springframework.security.config.annotation.web.configuration;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;

public class WebSecurityConfigurerAdapter {

	protected void configure(HttpSecurity http) throws Exception {
		// TODO Auto-generated method stub
		
	}

	public void configure(WebSecurity web) throws Exception {
		// TODO Auto-generated method stub
		
	}

}
