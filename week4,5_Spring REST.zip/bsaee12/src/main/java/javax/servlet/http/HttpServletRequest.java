package javax.servlet.http;

public class HttpServletRequest {

	public String getHeader(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
