package BookStoreAPI.example.bsaee12;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bsaee12ApplicationTests {

	@Test
	void contextLoads() {
	}

}
