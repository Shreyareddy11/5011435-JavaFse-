package BookStoreAPI.example.bsaex6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bsaex6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
