package BookStoreAPI.example.bsaex7;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

@Service
public class BookService {

    private final List<Book> books = new ArrayList<>();

    public List<BookDTO> findAll() {
        return books.stream()
                .map(BookMapper.INSTANCE::bookToBookDTO)
                .collect(Collectors.toList());
    }

    public Optional<BookDTO> findById(Long id) {
        return books.stream()
                .filter(book -> book.getId().equals(id))
                .map(BookMapper.INSTANCE::bookToBookDTO)
                .findFirst();
    }

    public BookDTO save(BookDTO bookDTO) {
        Book book = BookMapper.INSTANCE.bookDTOToBook(bookDTO);
        books.add(book);
        return bookDTO;
    }

    public void deleteById(Long id) {
        books.removeIf(book -> book.getId().equals(id));
    }

    public BookDTO updateBook(Long id, BookDTO bookDTO) {
        Book existingBook = books.stream()
                .filter(book -> book.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new BookNotFoundException("Book not found with id " + id));

        existingBook.setTitle(bookDTO.getTitle());
        existingBook.setAuthor(bookDTO.getAuthor());
        existingBook.setPrice(bookDTO.getPrice());

        return BookMapper.INSTANCE.bookToBookDTO(existingBook);
    }

	public Book save(Book book) {
		// TODO Auto-generated method stub
		return null;
	}
}
