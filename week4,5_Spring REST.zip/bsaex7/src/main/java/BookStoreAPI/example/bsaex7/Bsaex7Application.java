package BookStoreAPI.example.bsaex7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bsaex7Application {

	public static void main(String[] args) {
		SpringApplication.run(Bsaex7Application.class, args);
	}

}
