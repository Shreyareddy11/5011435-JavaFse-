package BookStoreAPI.example.bsaex7;


import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.http.HttpStatus;

@Data
@AllArgsConstructor
public class ErrorResponse {
    public ErrorResponse(HttpStatus internalServerError, String message2, String description) {
		// TODO Auto-generated constructor stub
	}
	private HttpStatus status;
    private String message;
    private String details;
}
