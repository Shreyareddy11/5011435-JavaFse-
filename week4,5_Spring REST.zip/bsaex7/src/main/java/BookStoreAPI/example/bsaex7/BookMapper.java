package BookStoreAPI.example.bsaex7;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

public interface BookMapper
{

    BookMapper INSTANCE = Mapper(BookMapper.class);

    BookDTO bookToBookDTO(Book book);

    static BookMapper Mapper(Class<BookMapper> class1) {
		// TODO Auto-generated method stub
		return null;
	}

	Book bookDTOToBook(BookDTO bookDTO);
}
