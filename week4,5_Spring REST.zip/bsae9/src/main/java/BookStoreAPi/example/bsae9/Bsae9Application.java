package BookStoreAPi.example.bsae9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bsae9Application {

	public static void main(String[] args) {
		SpringApplication.run(Bsae9Application.class, args);
	}

}
