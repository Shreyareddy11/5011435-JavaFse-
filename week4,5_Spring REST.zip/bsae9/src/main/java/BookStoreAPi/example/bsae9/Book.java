package BookStoreAPi.example.bsae9;

public class Book {

    private Long id;
    private String title;
    private String author;
    private double price;
    private String isbn;
	public Object getTitle() {
		// TODO Auto-generated method stub
		return null;
	}
	public Object getAuthor() {
		// TODO Auto-generated method stub
		return null;
	}
	public Object getPrice() {
		// TODO Auto-generated method stub
		return null;
	}
	public Object getIsbn() {
		// TODO Auto-generated method stub
		return null;
	}
	public void setTitle(Object title2) {
		// TODO Auto-generated method stub
		
	}
	public void setAuthor(Object author2) {
		// TODO Auto-generated method stub
		
	}
	public void setPrice(Object price2) {
		// TODO Auto-generated method stub
		
	}
	public void setIsbn(Object isbn2) {
		// TODO Auto-generated method stub
		
	}
	public Object getId() {
		// TODO Auto-generated method stub
		return null;
	}

    // Getters and Setters
    // ...
}
