package BookStoreAPi.example.bsae9;

import com.example.bookstore.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookRepository  {

	void delete(BookStoreAPi.example.bsae9.Book book);

	Object findById(Long id);

	BookStoreAPi.example.bsae9.Book save(BookStoreAPi.example.bsae9.Book book);

	Object findAll();
}
