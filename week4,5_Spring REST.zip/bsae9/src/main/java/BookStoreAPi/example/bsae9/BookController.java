package BookStoreAPi.example.bsae9;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/books")
public class BookController {

    private BookRepository bookRepository;

    public EntityModel getBookById(@PathVariable Long id) {
        Object book = ((Object) bookRepository.findById(id));

        // Create the EntityModel and add links
        EntityModel resource = EntityModel.of(book);

        // Add self-link
        resource.add(((Link) WebMvcLinkBuilder.linkTo(((BookController) WebMvcLinkBuilder.methodOn(BookController.class)).getBookById(id))).withSelfRel());

        // Add link to all books
        resource.add(((Link) WebMvcLinkBuilder.linkTo(((BookController) WebMvcLinkBuilder.methodOn(BookController.class)).getBookById(id))).withSelfRel());

        return resource;
    }

    }
