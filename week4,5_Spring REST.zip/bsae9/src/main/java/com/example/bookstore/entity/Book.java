package com.example.bookstore.entity;

public class Book {

}
