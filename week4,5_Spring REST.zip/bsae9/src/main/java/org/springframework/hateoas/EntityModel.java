package org.springframework.hateoas;

import BookStoreAPi.example.bsae9.Book;

public class EntityModel {

	public static EntityModel of(Object book) {
		// TODO Auto-generated method stub
		return null;
	}

	public static EntityModel empty() {
		// TODO Auto-generated method stub
		return null;
	}

	public void add(Link withSelfRel) {
		// TODO Auto-generated method stub
		
	}

}
