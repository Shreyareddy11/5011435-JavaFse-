package org.springframework.hateoas.server.mvc;

import java.util.List;

import org.springframework.hateoas.EntityModel;

import BookStoreAPi.example.bsae9.BookController;
import ch.qos.logback.core.model.conditional.ElseModel;

public class WebMvcLinkBuilder {

	public static Object methodOn(Class<BookController> class1) {
		// TODO Auto-generated method stub
		return null;
	}

	public static Object linkTo(EntityModel entityModel) {
		// TODO Auto-generated method stub
		return null;
	}

	public static Object linkTo(List<EntityModel> allBooks) {
		// TODO Auto-generated method stub
		return null;
	}

}
