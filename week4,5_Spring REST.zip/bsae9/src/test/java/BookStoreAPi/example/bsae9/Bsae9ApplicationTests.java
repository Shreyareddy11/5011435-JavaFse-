package BookStoreAPi.example.bsae9;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bsae9ApplicationTests {

	@Test
	void contextLoads() {
	}

}
