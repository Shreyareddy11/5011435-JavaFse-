package BookstoreAPI.example.bsaex2.model;

public class Book {

}
