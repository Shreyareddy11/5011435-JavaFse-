package BookstoreAPI.example.bsaex3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bsaex3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
