package BookstoreAPI.example.bsaex4;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Customer {
    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
	public void setFirstName(String firstName2) {
		// TODO Auto-generated method stub
		
	}
	public void setLastName(String lastName2) {
		// TODO Auto-generated method stub
		
	}
	public void setPhoneNumber(String phoneNumber2) {
		// TODO Auto-generated method stub
		
	}
	public void setEmail(String email2) {
		// TODO Auto-generated method stub
		
	}
}
