package BookStoreAPi.example.bsae11;

public class BookRepository {

	public Book save(Book book) {
		// TODO Auto-generated method stub
		return null;
	}

}
