package BookStoreAPi.example.bsae11;

public class Book {

}
