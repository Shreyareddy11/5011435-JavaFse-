package BookStoreAPi.example.bsae11;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cglib.core.internal.CustomizerRegistry;
import org.springframework.stereotype.Service;
import org.w3c.dom.css.Counter;

public class BookService<bookCreationCounter> {

    private final BookRepository bookRepository;
    private final Counter bookCreationCounter;

    @Autowired
    public BookService(BookRepository bookRepository, CustomizerRegistry meterRegistry) {
        this.bookRepository = bookRepository;
		this.bookCreationCounter = null;
    }

    public <bookCreationCounter> Book createBook(Book book) {
        Book savedBook = bookRepository.save(book);
        return savedBook;
    }

}
