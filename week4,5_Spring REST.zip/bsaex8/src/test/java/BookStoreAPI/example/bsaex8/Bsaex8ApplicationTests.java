package BookStoreAPI.example.bsaex8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bsaex8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
