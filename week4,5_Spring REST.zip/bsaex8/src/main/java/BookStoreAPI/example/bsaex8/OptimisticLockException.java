package BookStoreAPI.example.bsaex8;

public interface OptimisticLockException {

}
