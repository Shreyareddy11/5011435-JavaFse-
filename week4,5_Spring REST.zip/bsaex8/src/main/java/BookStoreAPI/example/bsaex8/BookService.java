package BookStoreAPI.example.bsaex8;

import java.util.List;

public class BookService {

	public Book saveBook(Book book) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		return null;
	}

	public Book getBookById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public Book updateBook(Long id, Book bookDetails) {
		// TODO Auto-generated method stub
		return null;
	}

	public void deleteBook(Long id) {
		// TODO Auto-generated method stub
		
	}

}
