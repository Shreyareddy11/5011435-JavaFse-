package BookStoreAPI.example.bsaex8;

import java.math.BigDecimal;

public class Book {
   
    private Long id;

    private String title;

    private String author;

    private BigDecimal price;

    private String isbn;

    private Integer version;

    // Getters and setters
}
