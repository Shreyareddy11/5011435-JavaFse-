package BookStoreAPI.example.bsaex8;

import java.util.List;

public class Customer {
    private Long id;
    private String name;

    private String email;

    private String phoneNumber;

    private Integer version;

	public static Customer saveCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	public Customer getCustomerById(Long id2) {
		// TODO Auto-generated method stub
		return null;
	}

	public Customer updateCustomer(Long id2, Customer customerDetails) {
		// TODO Auto-generated method stub
		return null;
	}

	public void deleteCustomer(Long id2) {
		// TODO Auto-generated method stub
		
	}

    // Getters and setters
}
