package BookStoreAPI.example.bsaex8;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class GlobalExceptionHandler {

    
    public ResponseEntity<String> handleOptimisticLockException(OptimisticLockException ex) {
        return ResponseEntity.status(HttpStatus.CONFLICT).body("Conflict: The resource was updated by another transaction.");
    }

    // Other exception handlers
}
