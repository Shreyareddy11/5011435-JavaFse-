package BookStoreAPI.example.bsaex5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bsaex5Application {

	public static void main(String[] args) {
		SpringApplication.run(Bsaex5Application.class, args);
	}

}
