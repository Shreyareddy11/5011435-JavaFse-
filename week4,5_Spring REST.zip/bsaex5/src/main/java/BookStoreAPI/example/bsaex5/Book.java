package BookStoreAPI.example.bsaex5;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Book {
    private Long id;
    private String title;
    private String author;
    private Double price;
    private String isbn;
	public Object getId() {
		// TODO Auto-generated method stub
		return null;
	}
	public Object getTitle() {
		// TODO Auto-generated method stub
		return null;
	}
	public Object getAuthor() {
		// TODO Auto-generated method stub
		return null;
	}
	public Object getPrice() {
		// TODO Auto-generated method stub
		return null;
	}
	public Object getIsbn() {
		// TODO Auto-generated method stub
		return null;
	}
	public void setTitle(Object title2) {
		// TODO Auto-generated method stub
		
	}
	public void setAuthor(Object author2) {
		// TODO Auto-generated method stub
		
	}
	public void setPrice(Object price2) {
		// TODO Auto-generated method stub
		
	}
	public void setIsbn(Object isbn2) {
		// TODO Auto-generated method stub
		
	}
}
