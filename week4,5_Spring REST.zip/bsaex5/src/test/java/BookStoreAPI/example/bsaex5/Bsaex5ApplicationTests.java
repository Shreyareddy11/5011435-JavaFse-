package BookStoreAPI.example.bsaex5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bsaex5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
