CREATE OR REPLACE PROCEDURE ProcessMonthlyInterest IS
    CURSOR c_savings_accounts IS 
        SELECT AccountID, Balance 
        FROM Accounts 
        WHERE AccountType = 'Savings';
BEGIN
    FOR r_account IN c_savings_accounts LOOP
        UPDATE Accounts
        SET Balance = Balance + (Balance * 0.01)
        WHERE AccountID = r_account.AccountID;
    END LOOP;

    COMMIT;
END ProcessMonthlyInterest;
