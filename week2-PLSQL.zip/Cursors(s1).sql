DECLARE
    CURSOR c_transactions IS 
        SELECT AccountID, TransactionDate, Amount, TransactionType 
        FROM Transactions 
        WHERE TransactionDate BETWEEN TRUNC(SYSDATE, 'MM') AND LAST_DAY(SYSDATE);
BEGIN
    FOR r_transaction IN c_transactions LOOP
        DBMS_OUTPUT.PUT_LINE('Account ID: ' || r_transaction.AccountID || 
                             ', Date: ' || r_transaction.TransactionDate || 
                             ', Amount: ' || r_transaction.Amount || 
                             ', Type: ' || r_transaction.TransactionType);
    END LOOP;
END;
