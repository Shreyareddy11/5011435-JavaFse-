CREATE OR REPLACE FUNCTION CalculateMonthlyInstallment(
    p_loan_amount NUMBER,
    p_interest_rate NUMBER,
    p_duration_years NUMBER
) RETURN NUMBER IS
    v_monthly_installment NUMBER;
BEGIN
    v_monthly_installment := p_loan_amount * p_interest_rate / 1200 / (1 - POWER(1 + p_interest_rate / 1200, -p_duration_years * 12));
    RETURN v_monthly_installment;
END CalculateMonthlyInstallment;
