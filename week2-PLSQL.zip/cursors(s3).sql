DECLARE
    CURSOR c_loans IS 
        SELECT LoanID, InterestRate 
        FROM Loans;
BEGIN
    FOR r_loan IN c_loans LOOP
        UPDATE Loans
        SET InterestRate = r_loan.InterestRate * 1.02
        WHERE LoanID = r_loan.LoanID;
    END LOOP;

    COMMIT;
END;
