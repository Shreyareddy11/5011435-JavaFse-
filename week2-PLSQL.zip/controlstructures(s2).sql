ALTER TABLE Customers ADD (IsVIP VARCHAR2(1));

DECLARE
    CURSOR c_customers IS SELECT CustomerID, Balance FROM Customers;
BEGIN
    FOR r_customer IN c_customers LOOP
        IF r_customer.Balance > 10000 THEN
            UPDATE Customers
            SET IsVIP = 'Y'
            WHERE CustomerID = r_customer.CustomerID;
        END IF;
    END LOOP;
END;
