DECLARE
    CURSOR c_loans IS 
        SELECT LoanID, CustomerID, EndDate 
        FROM Loans 
        WHERE EndDate BETWEEN SYSDATE AND SYSDATE + 30;
BEGIN
    FOR r_loan IN c_loans LOOP
        DBMS_OUTPUT.PUT_LINE('Reminder: Loan ID ' || r_loan.LoanID || ' for Customer ID ' || r_loan.CustomerID || ' is due on ' || r_loan.EndDate);
    END LOOP;
END;
