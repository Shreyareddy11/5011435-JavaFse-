public class EC {
    public static void main(String[] args) {
        Product[] products = {
            new Product("1", "Tablet", "Electronics"),
            new Product("2", "Smartphone", "Electronics"),
            new Product("3", "Tablet", "Electronics"),
            new Product("4", "Headphones", "Accessories"),
            new Product("5", "Charger", "Accessories")
        };

        // Linear Search
        Product foundProduct = LinearSearch.linearSearch(products, "Charger");
        System.out.println("Linear Search Result: " + (foundProduct != null ? foundProduct : "Product not found"));

        // Binary Search
        foundProduct = BinarySearch.binarySearch(products, "Tablet");
        System.out.println("Binary Search Result: " + (foundProduct != null ? foundProduct : "Product not found"));
    }
}
