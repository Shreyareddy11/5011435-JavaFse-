public class EMS {
    private Employee[] employees;
    private int count;

    public EMS(int capacity) {
        employees = new Employee[capacity];
        count = 0;
    }

    public void addEmployee(Employee employee) {
        if (count == employees.length) {
            System.out.println("Array is full, cannot add more employees.");
            return;
        }
        employees[count++] = employee;
    }

    public Employee searchEmployee(int employeeId) {
        for (int i = 0; i < count; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                return employees[i];
            }
        }
        return null;
    }

    public void traverseEmployees() {
        for (int i = 0; i < count; i++) {
            System.out.println(employees[i]);
        }
    }

    public void deleteEmployee(int employeeId) {
        int index = -1;
        for (int i = 0; i < count; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                index = i;
                break;
            }
        }

        if (index == -1) {
            System.out.println("Employee not found.");
            return;
        }

        for (int i = index; i < count - 1; i++) {
            employees[i] = employees[i + 1];
        }
        employees[--count] = null;
    }

    public static void main(String[] args) {
        EMS system = new EMS(10);
        
        system.addEmployee(new Employee(1, "shreya", "Manager", 90000));
        system.addEmployee(new Employee(2, "sravani", "Developer", 80000));
        system.addEmployee(new Employee(3, "bindhu", "Analyst", 70000));
        
        System.out.println("All Employees:");
        system.traverseEmployees();
        
        System.out.println("\nSearch for Employee with ID 2:");
        System.out.println(system.searchEmployee(2));
        
        System.out.println("\nDelete Employee with ID 2:");
        system.deleteEmployee(2);
        
        System.out.println("\nAll Employees after deletion:");
        system.traverseEmployees();
    }
}
