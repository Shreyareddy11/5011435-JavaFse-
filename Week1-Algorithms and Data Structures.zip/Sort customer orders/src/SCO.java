import java.util.Arrays;

public class SCO {
    public static void main(String[] args) {
        Order[] orders = {
            new Order("1", "A", 300.50),
            new Order("2", "B", 150.75),
            new Order("3", "C", 225.25),
            new Order("4", "D", 400.00),
        };

        System.out.println("Original Orders:");
        System.out.println(Arrays.toString(orders));

        // Bubble Sort
        Bubblesort.bubbleSort(orders);
        System.out.println("Bubble Sorted Orders:");
        System.out.println(Arrays.toString(orders));
        orders = new Order[] {
            new Order("1", "A", 300.50),
            new Order("2", "B", 150.75),
            new Order("3", "C", 225.25),
            new Order("4", "D", 400.00),
        };
        QuickSort.quickSort(orders, 0, orders.length - 1);
        System.out.println("Quick Sorted Orders:");
        System.out.println(Arrays.toString(orders));
    }
}
