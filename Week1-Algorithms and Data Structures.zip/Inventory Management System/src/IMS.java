
public class IMS {
    public static void main(String[] args) {
        Inventory inventory = new Inventory();
        inventory.addProduct(new Product("1", "sandals", 10, 999.99));
        inventory.addProduct(new Product("2", "kurti", 20, 499.99));
        inventory.displayProducts();
        inventory.updateProduct("1", 5, 899.99);
        System.out.println("Updated Product: " + inventory.getProduct("1"));
        inventory.deleteProduct("2");
        inventory.displayProducts();
    }
}
