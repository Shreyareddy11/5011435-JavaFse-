package EmployeeManagementSystemex3.ex3;
import lombok.Data;
public class Employee {
    private Long id;

    private String name;
    private String email;
    private Department department;
}
