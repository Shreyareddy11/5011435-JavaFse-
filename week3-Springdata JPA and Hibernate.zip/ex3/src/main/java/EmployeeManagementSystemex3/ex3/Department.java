package EmployeeManagementSystemex3.ex3;
import java.util.List;
import lombok.Data;
public class Department {
    private Long id;

    private String name;
    private List<Employee> employees;
}
