package EmployeeManagementSystemex4.ex4;
import lombok.Data;
public class Employee {
    private Long id;

    private String name;
    private String email;
    private Department department;
	public Object getName() {
		// TODO Auto-generated method stub
		return null;
	}
	public Object getEmail() {
		// TODO Auto-generated method stub
		return null;
	}
	public Object getDepartment() {
		// TODO Auto-generated method stub
		return null;
	}
	public void setName(Object name2) {
		// TODO Auto-generated method stub
		
	}
	public void setEmail(Object email2) {
		// TODO Auto-generated method stub
		
	}
	public void setDepartment(Object department2) {
		// TODO Auto-generated method stub
		
	}
}
