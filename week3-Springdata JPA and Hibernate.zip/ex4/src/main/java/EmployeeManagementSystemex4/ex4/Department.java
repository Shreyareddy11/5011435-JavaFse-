package EmployeeManagementSystemex4.ex4;
import java.util.List;
import lombok.Data;
public class Department {
    private Long id;

    private String name;
    private List<Employee> employees;
	public Object getName() {
		
		return null;
	}
	public void setName(Object name2) {
		// TODO Auto-generated method stub
		
	}
}
