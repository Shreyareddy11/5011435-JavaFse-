package EmployeeManagementSystemex5.ex5;
import jakarta.persistence.*;
import lombok.Data;
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;

    @ManyToOne
    @JoinColumn(name = "department_id")
    private Department department;

	public void setId(Long id2) {
		// TODO Auto-generated method stub
		
	}
}
