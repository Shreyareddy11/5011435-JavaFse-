package EmployeeManagementSystemex5.ex5;
import EmployeeManagementSystemex5.ex5.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    // Find employees by their name
    List<Employee> findByName(String name);

    // Find employees by their department's name
    List<Employee> findByDepartmentName(String departmentName);

    // Find employees by their email containing a specific string
    List<Employee> findByEmailContaining(String keyword);
}
