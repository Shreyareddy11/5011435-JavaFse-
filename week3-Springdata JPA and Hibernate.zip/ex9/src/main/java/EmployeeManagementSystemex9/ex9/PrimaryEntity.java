package EmployeeManagementSystemex9.ex9;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PrimaryEntity extends JpaRepository<PrimaryEntity, Long> {
}
