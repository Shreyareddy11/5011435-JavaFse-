package EmployeeManagementSystemex9.ex9;
public interface EmployeeNameProjection {
    String getName();
}
